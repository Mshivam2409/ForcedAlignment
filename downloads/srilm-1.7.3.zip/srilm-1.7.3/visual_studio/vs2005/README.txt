
These projects can be used to build SRILM using the Microsoft Visual
Studio 2005 IDE.  For instructions, see
SRILM/doc/README.windows-msvc-visual-studio.

If you want to compile using a different version of MSVC, I suggest
creating a new subdirectory of SRILM/visual_studio, e.g.,
"SRILM/visual_studio/vs2010", and copying the contents of the "vs2005"
directory into your new directory.  Then use MSVC to update your
projects.  If you need to downgrade to MSVC 2003, it is possible to do
this by manually editing the project files.

I would like to thank Keith Vertanen (http://www.keithv.com) for
contributing the original versions of these Microsoft Visual Studio
projects to SRILM.

Victor Abrash
victor@speech.sri.com
